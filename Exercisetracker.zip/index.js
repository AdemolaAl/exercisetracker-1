const express = require('express')
const app = express()
const cors = require('cors')
require('dotenv').config()
let bodyParser= require('body-parser')
const mongoose= require('mongoose')
app.use(cors())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json()); 
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true }); 

let exerciseSchema = new mongoose.Schema({
  username: String ,
  duration: Number,
  description:String,
  date:{type: String}
},{ versionKey: false })
const exercise = mongoose.model("exercise", exerciseSchema)

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html')
});

app.route('/api/users').post(async (req, res)=>{
const username = req.body.username;
  
const user =  new exercise({username: username})
  await user.save();
  
  const findUser= await exercise.find({username: username});
  
  const id= findUser[0]._id;
  
  res.json({username: username, _id: id })

})


  app.get("/api/users", async(req, res)=>{
  const fin = await exercise.find()
  res.json(fin)
})


app.post("/api/users/:_id/exercises", async(req,res)=>{
  const description= req.body.description;
  
  const duration= req.body.duration; 
  
const dat= req.body.date;
  var dates= new Date(dat).toDateString()
 if(dat==""){dates= new Date().toDateString()}
  
  const id= req.body._id;
  console.log(id);
  
 await exercise.updateOne({"_id": id}, {$set : { duration: duration,description: description, date:dates},});               
  
  const findUser= await exercise.find({"_id": id});
  const date= findUser[0].date;
  console.log(findUser);
  const username= findUser[0].username;

  
res.json({username: username ,description:findUser[0]. description, duration:findUser[0]. duration,date:findUser[0].date, _id: findUser[0]._id })
  
})

mongoose.connection.on("open",()=>{
const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port)
})
})